module.exports = {
  BOT_TOKEN: "7725721744:AAFFrWc2kTe8q6_DWzxFSPajGTEzyyNMf6c",
    allowedDevelopers: ['6836137819'], // ID
};